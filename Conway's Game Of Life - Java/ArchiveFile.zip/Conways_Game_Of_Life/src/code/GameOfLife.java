package code;

import javax.swing.JFrame;

/***
 * 
 * This is Conways Game of life
 * 
 * This code if from the book Think Java Second Edition, by Allen B. Downey & Chris Mayfield
 * 
 * I thought this program was cool so I coded it up from the book. 
 */
public class GameOfLife {
	private GridCanvas grid;
	
	public GameOfLife() {
		grid = new GridCanvas(20, 20, 20);
		
		// Set up the starting condition here
		grid.turnOn(10, 11);
		grid.turnOn(10, 12);
		grid.turnOn(10, 13);
		grid.turnOn(11, 12);
		
		grid.turnOn(5, 11);
		grid.turnOn(5, 12);
		grid.turnOn(5, 13);
		grid.turnOn(6, 12);
		
		grid.turnOn(10, 6);
		grid.turnOn(10, 7);
		grid.turnOn(10, 8);
		grid.turnOn(11, 7);
		
		
	}
	
	
	public static void main(String[] args) {
		String title = "Conway's Game of Life";
		GameOfLife game = new GameOfLife();
		JFrame frame = new JFrame(title);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.add(game.grid);
		frame.pack();
		frame.setVisible(true);
		game.mainloop();
	}
	
	
	private void mainloop() {
		while(true) {
			this.update();
			grid.repaint();
			try {
				Thread.sleep(500);
			}catch(InterruptedException e) {
				// do nothing
			}
		}
	}
	
	
	private int countAlive(int r, int c) {
		int count = 0;
		count += grid.test(r-1, c - 1);
		count += grid.test(r-1, c);
		count += grid.test(r-1, c+1);
		count += grid.test(r, c-1);
		count += grid.test(r,  c+1);
		count += grid.test(r+1, c-1);
		count += grid.test(r+1, c);
		count += grid.test(r+1, c+1);
		return count;
	}
	
	
	public void update() {
		int[][] counts = countNeighbors();
		updateGrid(counts);
	}
	
	
	private int[][] countNeighbors(){
		int rows = grid.numRows();
		int cols = grid.numCols();
		
		int[][] counts = new int[rows][cols];
		for (int r = 0; r < rows; r++) {
			for (int c = 0; c < cols; c++) {
				counts[r][c] = countAlive(r,c);
			}
				
		}
		
		return counts;
	}
	
	private void updateGrid(int[][] counts) {
		int rows = grid.numRows();
		int cols = grid.numCols();
		
		for (int r = 0; r < rows; r ++) {
			for (int c = 0; c < cols; c++) {
				Cell cell = grid.getCell(r, c);
				updateCell(cell, counts[r][c]);
			}
		}
		
	}
	
	private void updateCell(Cell cell, int count) {
		if (cell.isOn()) {
			if (count < 2 || count > 3) {
				cell.turnOff();
			}
		}else {
			if (count == 3) {
				cell.turnOn();
			}
		}
	}
	
}
